package final_IDJW2018;

public class AppClass {

	public static void main(String[] args) {
		Tokenizer tok = new Tokenizer();
		Restaurant_IDJW[] arr = tok.getTokensFromRest();
		MenuListAdvanced_IDJW abc = new MenuListAdvanced_IDJW();
		for(Restaurant_IDJW x : arr) {
			abc.add(x);
		}
		abc.mainMenu();
	}
}
