package final_IDJW2018;

import  java.util.Scanner;
import java.io.*;
public class Tokenizer {
	private String tokenFilesss;
	public Tokenizer() {
		tokenFilesss = "";
	}
	public Tokenizer(String tokenFile) {
		tokenFilesss = tokenFile;
	}
	public void setFile(String tkF) {
		tokenFilesss = tkF;
	}
	public String getFile() {
		return tokenFilesss;
	}
	public Restaurant_IDJW[] getTokensFromRest(){
		int size = 0;
		try {
			File readFrom2 = new File("RestaurantList.txt");
			Scanner counter = new Scanner(readFrom2);
			while(counter.hasNextLine()) {
				String a = counter.nextLine();
				size++;
			}
			counter.close();
		}catch(FileNotFoundException e) {
			System.out.println("Input File is not dfgdfgdfg.");
		}

		Restaurant_IDJW[] array = new Restaurant_IDJW[size]; 
		int index = 0;
		try {
			File readFrom = new File("RestaurantList.txt");
			Scanner reading = new Scanner(readFrom);
			while(reading.hasNextLine()) {
				String token = reading.nextLine();
				String[] splitToken = token.split(",");
				Double price = Double.parseDouble(splitToken[4]);
				
				try {
					
					Double radius = Double.parseDouble(splitToken[6]);
					array[index] = new Truck_IDJW(splitToken[0],splitToken[1],splitToken[2],splitToken[3],price,splitToken[5],radius);

							index++;
				}catch(Exception e) {
					if((splitToken[6].toLowerCase().equals("true")) || (splitToken[6].toLowerCase().equals("false"))) {
						//System.out.println("this");
						boolean trueOrNot = Boolean.parseBoolean(splitToken[6]);
						array[index] = new Sit_Down_IDJW(splitToken[0],splitToken[1],splitToken[2],splitToken[3],price,splitToken[5],trueOrNot);

						index++;
					}else {
						
						array[index] = new Stand_IDJW(splitToken[0],splitToken[1],splitToken[2],splitToken[3],price,splitToken[5],splitToken[6]);

						index++;
					}
				}
			
		
				
				
			}
			reading.close();
		}catch(FileNotFoundException e) {
			System.out.println("Input File is not foundfgdfgd.");
		}
		return array;
	}
}
