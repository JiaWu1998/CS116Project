package final_IDJW2018;

public abstract class Sanitation_IDJW {

	public abstract String getSanitationStatus();
	
}
